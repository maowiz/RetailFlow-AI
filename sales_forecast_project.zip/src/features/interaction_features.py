
class InteractionFeatureEngineer:
    def create_all_interaction_features(self, df): return df
